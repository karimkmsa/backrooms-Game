# Godot 3.4 maze generation
## (migration from Unity/C-Sharp)

Here I translate into Godot a maze generator that I [made in Unity](https://www.youtube.com/watch?v=Uo4GCrN2eOY&t=2s&ab_channel=QuickGameDevTutorials) using the [Aldous-Broder algorithm](https://en.wikipedia.org/wiki/Maze_generation_algorithm#Aldous-Broder_algorithm).  The video for this codebase can be found [here](https://www.youtube.com/watch?v=rVvJ_NY2IXg&ab_channel=QuickGameDevTutorials).

![Maze Generation Screenshot of Godot Screen](GD_Maze_Gen.png) 
